# 🔥 Flame — Guyana's #1 Dating Platform

**flame.gy** — Meet real Guyanese singles. Browse profiles, view photo galleries, and connect instantly via WhatsApp.

## Tech Stack
- **React 18** + **Vite** (fast builds)
- **React Router** (client-side routing)
- Deployed on **Vercel**
- Domain: **flame.gy**

## Features
- 🔥 Landing page with animated hero
- 👤 Profile cards with photo galleries
- 💬 Direct WhatsApp contact buttons
- 🔍 Filter by age, city across Guyana
- 📱 Fully responsive (mobile-first)
- ❤️ Donate/Patron system
- ✅ Verified profile badges
- 🇬🇾 Guyana-only (14 cities)

## Getting Started

```bash
# Install dependencies
npm install

# Run dev server
npm run dev

# Build for production
npm run build

# Preview production build
npm run preview
```

## Deploy to Vercel

### Option 1: Git Integration (Recommended)
1. Push this repo to GitHub:
   ```bash
   git init
   git add .
   git commit -m "🔥 Initial commit - Flame dating platform"
   git branch -M main
   git remote add origin https://github.com/YOUR_USERNAME/flame-dating.git
   git push -u origin main
   ```

2. Go to [vercel.com](https://vercel.com) → Import Project → Select your GitHub repo

3. Vercel auto-detects Vite — just click **Deploy**

4. Add custom domain:
   - Go to Project Settings → Domains
   - Add `flame.gy`
   - Update your DNS:
     - **A Record**: `76.76.21.21`
     - **CNAME**: `cname.vercel-dns.com` (for `www.flame.gy`)

### Option 2: Vercel CLI
```bash
npm i -g vercel
vercel --prod
```

## Domain Setup (flame.gy)

In your domain registrar's DNS settings:

| Type  | Name | Value               |
|-------|------|---------------------|
| A     | @    | 76.76.21.21         |
| CNAME | www  | cname.vercel-dns.com|

## Project Structure
```
flame-dating/
├── public/
│   └── favicon.svg
├── src/
│   ├── components/
│   │   ├── DonateModal.jsx
│   │   ├── Footer.jsx
│   │   ├── GalleryModal.jsx
│   │   ├── Icons.jsx
│   │   ├── Navbar.jsx
│   │   ├── ProfileCard.jsx
│   │   └── SignUpModal.jsx
│   ├── data/
│   │   └── profiles.js
│   ├── pages/
│   │   ├── BrowsePage.jsx
│   │   └── HomePage.jsx
│   ├── App.jsx
│   ├── index.css
│   └── main.jsx
├── index.html
├── package.json
├── vercel.json
├── vite.config.js
└── README.md
```

## License
© 2026 Flame Dating — Georgetown, Guyana 🇬🇾
