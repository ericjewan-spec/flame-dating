import { useState } from 'react';
import ProfileCard from '../components/ProfileCard';
import { PROFILES, GUYANA_CITIES } from '../data/profiles';

export default function BrowsePage({ onOpenGallery, onSignUp }) {
  const [filters, setFilters] = useState({ ageMin: '', ageMax: '', city: '', gender: '' });
  const [showFilters, setShowFilters] = useState(true);

  const filtered = PROFILES.filter((p) => {
    if (filters.ageMin && p.age < parseInt(filters.ageMin)) return false;
    if (filters.ageMax && p.age > parseInt(filters.ageMax)) return false;
    if (filters.city && p.city !== filters.city) return false;
    return true;
  });

  const inputStyle = {
    background: 'var(--bg-input)', border: '1px solid #333', borderRadius: 8,
    padding: '8px 12px', color: 'var(--text-primary)', fontSize: 14,
    fontFamily: 'var(--font-body)', outline: 'none',
  };

  return (
    <div style={{ paddingTop: 90, maxWidth: 1200, margin: '0 auto', padding: '90px 24px 60px' }}>
      {/* Header */}
      <div style={{ marginBottom: 28, display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', flexWrap: 'wrap', gap: 16 }}>
        <div>
          <h1 style={{ fontFamily: 'var(--font-display)', fontSize: 40, marginBottom: 6 }}>
            Discover Singles
          </h1>
          <p style={{ color: 'var(--text-dim)', fontSize: 16 }}>
            {filtered.length} {filtered.length === 1 ? 'person' : 'people'} in Guyana
          </p>
        </div>
        <button onClick={() => setShowFilters(!showFilters)} style={{
          background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.1)',
          borderRadius: 10, padding: '10px 20px', color: '#ccc', fontSize: 14, cursor: 'pointer',
        }}>
          {showFilters ? '✕ Hide Filters' : '⚙ Show Filters'}
        </button>
      </div>

      {/* Filters */}
      {showFilters && (
        <div className="filter-bar" style={{
          display: 'flex', gap: 20, flexWrap: 'wrap', marginBottom: 32,
          padding: 20, background: '#111', borderRadius: 16,
          border: '1px solid rgba(255,255,255,0.06)',
          animation: 'fadeUp 0.3s ease',
        }}>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
            <label style={{ fontSize: 11, textTransform: 'uppercase', letterSpacing: 1, color: '#555' }}>
              Age Range
            </label>
            <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
              <input style={{ ...inputStyle, width: 70 }} type="number" placeholder="18"
                value={filters.ageMin}
                onChange={(e) => setFilters({ ...filters, ageMin: e.target.value })} />
              <span style={{ color: '#555' }}>to</span>
              <input style={{ ...inputStyle, width: 70 }} type="number" placeholder="99"
                value={filters.ageMax}
                onChange={(e) => setFilters({ ...filters, ageMax: e.target.value })} />
            </div>
          </div>

          <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
            <label style={{ fontSize: 11, textTransform: 'uppercase', letterSpacing: 1, color: '#555' }}>
              City
            </label>
            <select style={{ ...inputStyle, width: 180, appearance: 'auto' }}
              value={filters.city}
              onChange={(e) => setFilters({ ...filters, city: e.target.value })}>
              <option value="">All of Guyana</option>
              {GUYANA_CITIES.map((c) => <option key={c} value={c}>{c}</option>)}
            </select>
          </div>

          {(filters.ageMin || filters.ageMax || filters.city) && (
            <button onClick={() => setFilters({ ageMin: '', ageMax: '', city: '', gender: '' })}
              style={{
                alignSelf: 'flex-end', background: 'none', border: 'none',
                color: '#FF6B35', fontSize: 13, cursor: 'pointer', padding: '8px 0',
              }}>
              ✕ Clear Filters
            </button>
          )}
        </div>
      )}

      {/* Grid */}
      <div className="profile-grid" style={{
        display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(320px, 1fr))', gap: 28,
      }}>
        {filtered.map((p, i) => (
          <div key={p.id} style={{ animation: `fadeUp 0.5s ease ${i * 0.06}s both` }}>
            <ProfileCard profile={p} onOpenGallery={onOpenGallery} />
          </div>
        ))}
      </div>

      {/* Empty state */}
      {filtered.length === 0 && (
        <div style={{ textAlign: 'center', padding: '80px 20px' }}>
          <div style={{ fontSize: 56, marginBottom: 16 }}>🔍</div>
          <h3 style={{ fontFamily: 'var(--font-display)', fontSize: 24, marginBottom: 8 }}>
            No matches found
          </h3>
          <p style={{ color: '#666', marginBottom: 24 }}>
            Try broadening your filters to see more people
          </p>
          <button onClick={() => setFilters({ ageMin: '', ageMax: '', city: '', gender: '' })}
            style={{
              background: 'rgba(255,107,53,0.1)', border: '1px solid rgba(255,107,53,0.3)',
              color: '#FF6B35', padding: '12px 28px', borderRadius: 50, fontSize: 14,
              fontWeight: 600, cursor: 'pointer',
            }}>
            Clear All Filters
          </button>
        </div>
      )}

      {/* Bottom CTA */}
      {filtered.length > 0 && (
        <div style={{
          textAlign: 'center', padding: '60px 20px', marginTop: 40,
          borderTop: '1px solid rgba(255,255,255,0.05)',
        }}>
          <p style={{ color: '#555', fontSize: 15, marginBottom: 16 }}>
            Want to be featured? Create your profile today.
          </p>
          <button onClick={onSignUp} style={{
            background: 'linear-gradient(135deg, #FF6B35, #E8522A)',
            border: 'none', color: '#fff', padding: '14px 36px', borderRadius: 50,
            fontSize: 15, fontWeight: 600, cursor: 'pointer',
          }}>
            Sign Up Free 🔥
          </button>
        </div>
      )}
    </div>
  );
}
