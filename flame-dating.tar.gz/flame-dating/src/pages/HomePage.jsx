import { FlameIcon } from '../components/Icons';
import { PROFILES } from '../data/profiles';

export default function HomePage({ onSignUp, onDonate }) {
  return (
    <div>
      {/* ── Hero ── */}
      <section style={{
        position: 'relative', minHeight: '100vh', display: 'flex',
        alignItems: 'center', padding: '120px 24px 80px', overflow: 'hidden',
      }}>
        {/* Ambient glows */}
        <div style={{
          position: 'absolute', width: 600, height: 600, borderRadius: '50%',
          background: 'radial-gradient(circle, rgba(255,107,53,0.12) 0%, transparent 70%)',
          top: '10%', left: '5%', filter: 'blur(60px)', animation: 'pulse 4s ease infinite',
        }} />
        <div style={{
          position: 'absolute', width: 400, height: 400, borderRadius: '50%',
          background: 'radial-gradient(circle, rgba(0,151,57,0.08) 0%, transparent 70%)',
          bottom: '15%', right: '15%', filter: 'blur(50px)', animation: 'pulse 5s ease 1s infinite',
        }} />

        <div style={{ maxWidth: 620, position: 'relative', zIndex: 2 }}>
          {/* Live badge */}
          <div style={{ animation: 'fadeUp 0.8s ease both' }}>
            <div style={{
              display: 'inline-flex', alignItems: 'center', gap: 8,
              background: 'rgba(0,151,57,0.1)', border: '1px solid rgba(0,151,57,0.25)',
              borderRadius: 50, padding: '6px 18px', fontSize: 13, color: '#4ade80', marginBottom: 24,
            }}>
              <span style={{ width: 6, height: 6, borderRadius: '50%', background: '#4ade80', animation: 'pulse 2s ease infinite' }} />
              🇬🇾 Guyanese singles are online now
            </div>
          </div>

          <h1 style={{
            fontFamily: 'var(--font-display)', fontSize: 'clamp(42px, 6vw, 72px)',
            fontWeight: 700, lineHeight: 1.08, marginBottom: 20,
            animation: 'fadeUp 0.8s ease 0.1s both',
          }}>
            Find Your{' '}
            <span style={{
              background: 'linear-gradient(135deg, #FF6B35, #F7C948)',
              WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent',
            }}>Flame</span>{' '}
            in Guyana
          </h1>

          <p style={{
            fontSize: 18, color: '#999', lineHeight: 1.7, marginBottom: 36,
            maxWidth: 500, animation: 'fadeUp 0.8s ease 0.2s both',
          }}>
            Real people from Georgetown to Lethem. Browse profiles, see photo galleries,
            and connect instantly via WhatsApp. No games, no bots — just vibes.
          </p>

          <div style={{
            display: 'flex', gap: 16, flexWrap: 'wrap',
            animation: 'fadeUp 0.8s ease 0.3s both',
          }} className="hero-btns">
            <a href="/browse" style={{
              background: 'linear-gradient(135deg, #FF6B35, #E8522A)',
              border: 'none', color: '#fff', padding: '16px 36px', borderRadius: 50,
              fontSize: 16, fontWeight: 600, animation: 'glow 3s ease infinite',
              display: 'inline-block', textAlign: 'center',
            }}>
              Browse Singles 🔥
            </a>
            <button onClick={onSignUp} style={{
              background: 'transparent', border: '1px solid rgba(255,255,255,0.15)',
              color: '#f0ece4', padding: '16px 36px', borderRadius: 50, fontSize: 16,
              fontWeight: 500, cursor: 'pointer', transition: 'all 0.2s',
            }}>
              Create Your Profile
            </button>
          </div>

          {/* Stats */}
          <div style={{
            display: 'flex', gap: 28, marginTop: 52, alignItems: 'center',
            animation: 'fadeUp 0.8s ease 0.4s both',
          }} className="hero-stats">
            {[
              { num: '500+', label: 'Active Users' },
              { num: '100%', label: 'Guyanese' },
              { num: '14', label: 'Cities' },
            ].map((s, i) => (
              <div key={i} style={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
                <span style={{
                  fontFamily: 'var(--font-display)', fontSize: 28, fontWeight: 700, color: '#FF6B35',
                }}>{s.num}</span>
                <span style={{ fontSize: 12, color: '#555', textTransform: 'uppercase', letterSpacing: 1 }}>
                  {s.label}
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Floating preview cards (desktop) */}
        <div className="hero-cards-desktop" style={{
          position: 'absolute', right: '5%', top: 0, bottom: 0, width: '40%', display: 'none',
        }}>
          {PROFILES.slice(0, 3).map((p, i) => (
            <div key={p.id} style={{
              position: 'absolute', width: 200, borderRadius: 16, overflow: 'hidden',
              background: '#151515', boxShadow: '0 20px 40px rgba(0,0,0,0.5)',
              animation: `float 3s ease-in-out ${i * 0.5}s infinite, fadeUp 0.8s ease ${0.3 + i * 0.15}s both`,
              left: `${i * 33}%`, top: `${12 + i * 18}%`, zIndex: 3 - i,
            }}>
              <img src={p.photos[0]} alt={p.name} style={{ width: '100%', height: 240, objectFit: 'cover' }} />
              <div style={{ padding: '10px 14px' }}>
                <span style={{ fontWeight: 600, fontSize: 14 }}>{p.name}, {p.age}</span>
                <div style={{ fontSize: 12, color: '#888', marginTop: 2 }}>📍 {p.city}</div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* ── Cities ── */}
      <section style={{ padding: '80px 24px', background: '#080808' }}>
        <div style={{ maxWidth: 1200, margin: '0 auto', textAlign: 'center' }}>
          <h2 style={{ fontFamily: 'var(--font-display)', fontSize: 36, marginBottom: 12 }}>
            Singles Across{' '}
            <span style={{
              background: 'linear-gradient(135deg, #009739, #FFD100)',
              WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent',
            }}>Guyana</span>
          </h2>
          <p style={{ color: '#666', fontSize: 15, marginBottom: 40 }}>
            From the capital to the countryside — find someone near you
          </p>
          <div style={{ display: 'flex', flexWrap: 'wrap', justifyContent: 'center', gap: 10 }}>
            {[
              'Georgetown', 'Linden', 'New Amsterdam', 'Bartica',
              'Anna Regina', 'Corriverton', 'Rose Hall', 'Lethem',
              'Mahaica', 'Parika', 'Vreed-en-Hoop', 'Skeldon',
            ].map((city, i) => (
              <a key={city} href="/browse" style={{
                padding: '10px 22px', borderRadius: 50, fontSize: 14,
                background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.08)',
                color: '#aaa', transition: 'all 0.2s',
                animation: `fadeUp 0.4s ease ${i * 0.04}s both`,
              }}>
                📍 {city}
              </a>
            ))}
          </div>
        </div>
      </section>

      {/* ── Features ── */}
      <section style={{ padding: '100px 24px', maxWidth: 1200, margin: '0 auto' }}>
        <h2 style={{
          fontFamily: 'var(--font-display)', fontSize: 40, textAlign: 'center', marginBottom: 60,
        }}>
          Why{' '}
          <span style={{
            background: 'linear-gradient(135deg, #FF6B35, #F7C948)',
            WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent',
          }}>Flame</span>?
        </h2>
        <div style={{
          display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))', gap: 24,
        }}>
          {[
            { icon: '📷', title: 'Photo Galleries', desc: 'See multiple photos of each person before you connect. No surprises.' },
            { icon: '💬', title: 'WhatsApp Direct', desc: 'Skip the in-app chat. Message anyone directly on WhatsApp with one tap.' },
            { icon: '🇬🇾', title: '100% Guyanese', desc: 'Built for Guyana, by Guyana. Only real Guyanese singles from coast to hinterland.' },
            { icon: '🔒', title: 'Real Profiles', desc: 'Verified profiles only. No catfishing, no scams, no bots. Real people only.' },
          ].map((f, i) => (
            <div key={i} style={{
              background: 'linear-gradient(145deg, #141414, #101010)',
              border: '1px solid rgba(255,255,255,0.06)', borderRadius: 20, padding: 32,
              animation: `fadeUp 0.5s ease ${i * 0.1}s both`,
            }}>
              <div style={{ fontSize: 40, marginBottom: 16 }}>{f.icon}</div>
              <h3 style={{ fontSize: 18, fontWeight: 600, marginBottom: 8 }}>{f.title}</h3>
              <p style={{ fontSize: 14, color: '#777', lineHeight: 1.7 }}>{f.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* ── Donate CTA ── */}
      <section style={{
        position: 'relative', textAlign: 'center', padding: '80px 24px',
        background: 'linear-gradient(180deg, transparent, rgba(247,201,72,0.03), transparent)',
        overflow: 'hidden',
      }}>
        <div style={{
          position: 'absolute', width: 500, height: 500, borderRadius: '50%',
          background: 'radial-gradient(circle, rgba(247,201,72,0.08) 0%, transparent 70%)',
          top: '50%', left: '50%', transform: 'translate(-50%,-50%)', filter: 'blur(60px)',
        }} />
        <div style={{ position: 'relative', zIndex: 1 }}>
          <div style={{ fontSize: 48, marginBottom: 16 }}>❤️‍🔥</div>
          <h2 style={{ fontFamily: 'var(--font-display)', fontSize: 36, marginBottom: 12 }}>
            Support the Movement
          </h2>
          <p style={{ color: '#777', fontSize: 16, marginBottom: 32, maxWidth: 480, margin: '0 auto 32px' }}>
            Flame is 100% free and ad-free for every Guyanese. Help us keep the lights on
            and the love flowing with a small donation.
          </p>
          <button onClick={onDonate} style={{
            background: 'linear-gradient(135deg, #F7C948, #FF6B35)',
            border: 'none', color: '#000', padding: '18px 48px', borderRadius: 50,
            fontSize: 18, fontWeight: 700, cursor: 'pointer',
          }}>
            ❤️ Become a Patron
          </button>
        </div>
      </section>

      {/* ── Final CTA ── */}
      <section style={{
        position: 'relative', textAlign: 'center', padding: '100px 24px', overflow: 'hidden',
      }}>
        <div style={{
          position: 'absolute', width: 500, height: 500, borderRadius: '50%',
          background: 'radial-gradient(circle, rgba(255,107,53,0.1) 0%, transparent 70%)',
          top: '50%', left: '50%', transform: 'translate(-50%,-50%)', filter: 'blur(60px)',
        }} />
        <h2 style={{
          fontFamily: 'var(--font-display)', fontSize: 40, position: 'relative', zIndex: 1, marginBottom: 16,
        }}>
          Ready to Find Your Match?
        </h2>
        <p style={{ color: '#777', fontSize: 16, position: 'relative', zIndex: 1, marginBottom: 36 }}>
          Join hundreds of Guyanese singles already connecting on Flame
        </p>
        <button onClick={onSignUp} style={{
          position: 'relative', zIndex: 1,
          background: 'linear-gradient(135deg, #FF6B35, #E8522A)',
          border: 'none', color: '#fff', padding: '18px 48px', borderRadius: 50,
          fontSize: 18, fontWeight: 600, cursor: 'pointer',
        }}>
          Get Started — It's Free 🔥
        </button>
      </section>
    </div>
  );
}
