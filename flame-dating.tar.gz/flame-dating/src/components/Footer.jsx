import { Link } from 'react-router-dom';
import { FlameIcon } from './Icons';

export default function Footer({ onDonate }) {
  return (
    <footer style={{
      borderTop: '1px solid rgba(255,255,255,0.05)',
      padding: '48px 24px 32px',
      background: '#080808',
    }}>
      <div style={{
        maxWidth: 1200, margin: '0 auto',
        display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))',
        gap: 40,
      }}>
        {/* Brand */}
        <div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 12 }}>
            <FlameIcon size={24} />
            <span style={{ fontFamily: 'var(--font-display)', fontSize: 22, fontWeight: 700 }}>
              Flame
            </span>
          </div>
          <p style={{ fontSize: 13, color: '#555', lineHeight: 1.7 }}>
            Guyana's #1 dating platform. Meet real singles in Georgetown, Linden,
            New Amsterdam, and across the country.
          </p>
          <div style={{ display: 'flex', gap: 4, marginTop: 12 }}>
            <span style={{ fontSize: 20 }}>🇬🇾</span>
            <span style={{ fontSize: 13, color: '#666', alignSelf: 'center' }}>
              Made with love in Guyana
            </span>
          </div>
        </div>

        {/* Quick links */}
        <div>
          <h4 style={{ fontSize: 13, textTransform: 'uppercase', letterSpacing: 1, color: '#555', marginBottom: 16 }}>
            Quick Links
          </h4>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
            <Link to="/browse" style={{ fontSize: 14, color: '#888', transition: 'color 0.2s' }}>
              Browse Singles
            </Link>
            <a href="#" style={{ fontSize: 14, color: '#888' }}>About Flame</a>
            <a href="#" style={{ fontSize: 14, color: '#888' }}>Safety Tips</a>
            <a href="#" style={{ fontSize: 14, color: '#888' }}>Privacy Policy</a>
          </div>
        </div>

        {/* Support */}
        <div>
          <h4 style={{ fontSize: 13, textTransform: 'uppercase', letterSpacing: 1, color: '#555', marginBottom: 16 }}>
            Support Flame
          </h4>
          <p style={{ fontSize: 13, color: '#666', lineHeight: 1.7, marginBottom: 12 }}>
            Flame is free and ad-free. Help us keep it that way for the Guyanese community.
          </p>
          <button onClick={onDonate} style={{
            background: 'rgba(247,201,72,0.1)', border: '1px solid rgba(247,201,72,0.3)',
            color: '#F7C948', padding: '10px 20px', borderRadius: 50, fontSize: 13,
            fontWeight: 600, cursor: 'pointer', transition: 'all 0.2s',
          }}>
            ❤️ Donate Now
          </button>
        </div>

        {/* Contact */}
        <div>
          <h4 style={{ fontSize: 13, textTransform: 'uppercase', letterSpacing: 1, color: '#555', marginBottom: 16 }}>
            Contact
          </h4>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
            <a href="https://wa.me/5926001000" target="_blank" rel="noopener noreferrer"
              style={{ fontSize: 14, color: '#25D366' }}>
              💬 WhatsApp
            </a>
            <a href="mailto:hello@flame.gy" style={{ fontSize: 14, color: '#888' }}>
              ✉️ hello@flame.gy
            </a>
          </div>
        </div>
      </div>

      <div style={{
        maxWidth: 1200, margin: '32px auto 0', paddingTop: 24,
        borderTop: '1px solid rgba(255,255,255,0.03)',
        display: 'flex', justifyContent: 'space-between', alignItems: 'center',
        flexWrap: 'wrap', gap: 12,
      }}>
        <p style={{ color: '#333', fontSize: 12 }}>
          © 2026 Flame Dating — flame.gy — All rights reserved.
        </p>
        <p style={{ color: '#333', fontSize: 12 }}>
          Georgetown, Guyana 🇬🇾
        </p>
      </div>
    </footer>
  );
}
