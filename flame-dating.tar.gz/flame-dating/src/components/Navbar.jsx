import { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { FlameIcon, MenuIcon, CloseIcon } from './Icons';

export default function Navbar({ onSignUp, onDonate }) {
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const handler = () => setScrolled(window.scrollY > 50);
    window.addEventListener('scroll', handler);
    return () => window.removeEventListener('scroll', handler);
  }, []);

  useEffect(() => {
    setMobileOpen(false);
  }, [location]);

  return (
    <>
      <nav style={{
        position: 'fixed', top: 0, left: 0, right: 0, zIndex: 100,
        transition: 'all 0.3s ease', padding: '0 24px',
        background: scrolled ? 'rgba(10,10,10,0.95)' : 'transparent',
        backdropFilter: scrolled ? 'blur(20px)' : 'none',
        borderBottom: scrolled ? '1px solid rgba(255,255,255,0.05)' : 'none',
      }}>
        <div style={{
          maxWidth: 1200, margin: '0 auto', display: 'flex',
          justifyContent: 'space-between', alignItems: 'center', height: 70,
        }}>
          <Link to="/" style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <FlameIcon size={28} />
            <span style={{ fontFamily: 'var(--font-display)', fontSize: 24, fontWeight: 700 }}>Flame</span>
            <span style={{
              fontSize: 10, padding: '2px 8px', borderRadius: 50,
              background: 'rgba(0,151,57,0.15)', color: '#4ade80',
              border: '1px solid rgba(0,151,57,0.3)', fontWeight: 600,
              letterSpacing: 1, textTransform: 'uppercase', marginLeft: 4,
            }}>GY</span>
          </Link>

          {/* Desktop nav */}
          <div className="nav-links-desktop" style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <Link to="/browse" style={{
              background: 'none', border: 'none', color: location.pathname === '/browse' ? '#FF6B35' : '#aaa',
              fontSize: 14, padding: '8px 16px', transition: 'color 0.2s',
            }}>Discover</Link>
            <button onClick={onDonate} style={{
              background: 'none', border: '1px solid rgba(247,201,72,0.3)',
              color: '#F7C948', fontSize: 14, padding: '8px 20px', borderRadius: 50,
              transition: 'all 0.2s', marginRight: 4,
            }}>
              ❤️ Donate
            </button>
            <button onClick={onSignUp} style={{
              background: 'linear-gradient(135deg, #FF6B35, #E8522A)',
              border: 'none', color: '#fff', padding: '10px 24px', borderRadius: 50,
              fontSize: 14, fontWeight: 600, transition: 'transform 0.2s, box-shadow 0.2s',
            }}>
              Sign Up Free
            </button>
          </div>

          {/* Mobile menu button */}
          <button className="mobile-menu-btn" onClick={() => setMobileOpen(!mobileOpen)} style={{
            display: 'none', alignItems: 'center', justifyContent: 'center',
            background: 'none', border: 'none', color: '#fff', padding: 8,
          }}>
            {mobileOpen ? <CloseIcon /> : <MenuIcon />}
          </button>
        </div>
      </nav>

      {/* Mobile menu dropdown */}
      {mobileOpen && (
        <div style={{
          position: 'fixed', top: 70, left: 0, right: 0, zIndex: 99,
          background: 'rgba(10,10,10,0.98)', backdropFilter: 'blur(20px)',
          borderBottom: '1px solid rgba(255,255,255,0.05)',
          padding: '16px 24px', animation: 'slideDown 0.2s ease',
          display: 'flex', flexDirection: 'column', gap: 12,
        }}>
          <Link to="/browse" style={{ color: '#ccc', fontSize: 16, padding: '12px 0' }}>Discover Singles</Link>
          <button onClick={() => { onDonate(); setMobileOpen(false); }} style={{
            background: 'none', border: '1px solid rgba(247,201,72,0.3)',
            color: '#F7C948', fontSize: 16, padding: '12px 0', borderRadius: 12, textAlign: 'center',
          }}>
            ❤️ Donate to Flame
          </button>
          <button onClick={() => { onSignUp(); setMobileOpen(false); }} style={{
            background: 'linear-gradient(135deg, #FF6B35, #E8522A)',
            border: 'none', color: '#fff', fontSize: 16, padding: '14px 0',
            borderRadius: 12, fontWeight: 600, textAlign: 'center',
          }}>
            Sign Up Free
          </button>
        </div>
      )}
    </>
  );
}
