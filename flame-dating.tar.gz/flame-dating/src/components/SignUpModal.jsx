import { useState } from 'react';
import { FlameIcon, CloseIcon } from './Icons';
import { GUYANA_CITIES } from '../data/profiles';

export default function SignUpModal({ onClose }) {
  const [form, setForm] = useState({
    name: '', age: '', email: '', city: 'Georgetown',
    phone: '', bio: '', gender: '',
  });
  const [step, setStep] = useState(1);
  const [done, setDone] = useState(false);

  const update = (k, v) => setForm({ ...form, [k]: v });

  const inputStyle = {
    background: 'var(--bg-input)', border: '1px solid #2a2a2a', borderRadius: 12,
    padding: '14px 16px', color: 'var(--text-primary)', fontSize: 15,
    fontFamily: 'var(--font-body)', outline: 'none', width: '100%',
    transition: 'border-color 0.2s',
  };
  const labelStyle = {
    fontSize: 12, textTransform: 'uppercase', letterSpacing: 1,
    color: 'var(--text-muted)', marginBottom: 6, display: 'block',
  };

  if (done) {
    return (
      <div style={overlayStyle} onClick={onClose}>
        <div style={modalStyle} onClick={(e) => e.stopPropagation()}>
          <div style={{ textAlign: 'center', padding: '60px 24px' }}>
            <div style={{ fontSize: 64, marginBottom: 20 }}>🔥</div>
            <h2 style={{ fontFamily: 'var(--font-display)', fontSize: 28, color: '#FF6B35' }}>
              Welcome to Flame!
            </h2>
            <p style={{ color: '#aaa', fontSize: 16, marginTop: 12, lineHeight: 1.6 }}>
              {form.name}, you're now part of Guyana's hottest dating community.
            </p>
            <button onClick={onClose} style={primaryBtnStyle}>
              Start Browsing 🔥
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div style={overlayStyle} onClick={onClose}>
      <div style={modalStyle} onClick={(e) => e.stopPropagation()}>
        <button onClick={onClose} style={closeBtnStyle}><CloseIcon size={18} /></button>

        <div style={{ textAlign: 'center', marginBottom: 28 }}>
          <FlameIcon size={36} />
          <h2 style={{ fontFamily: 'var(--font-display)', fontSize: 28, fontWeight: 700, marginTop: 12 }}>
            Join Flame
          </h2>
          <p style={{ color: 'var(--text-dim)', margin: '4px 0 0', fontSize: 14 }}>
            Step {step} of 2 — Guyana's #1 dating platform
          </p>
          <div style={{
            width: '100%', height: 3, background: '#222', borderRadius: 2,
            marginTop: 16, overflow: 'hidden',
          }}>
            <div style={{
              height: '100%', background: 'linear-gradient(90deg, #FF6B35, #F7C948)',
              borderRadius: 2, transition: 'width 0.4s ease',
              width: step === 1 ? '50%' : '100%',
            }} />
          </div>
        </div>

        {step === 1 && (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
            <div>
              <label style={labelStyle}>Your Name</label>
              <input style={inputStyle} value={form.name} onChange={(e) => update('name', e.target.value)}
                placeholder="What should we call you?" />
            </div>
            <div style={{ display: 'flex', gap: 12 }}>
              <div style={{ flex: 1 }}>
                <label style={labelStyle}>Age</label>
                <input style={inputStyle} type="number" value={form.age}
                  onChange={(e) => update('age', e.target.value)} placeholder="18+" min="18" />
              </div>
              <div style={{ flex: 1 }}>
                <label style={labelStyle}>I am a</label>
                <select style={{ ...inputStyle, appearance: 'auto' }} value={form.gender}
                  onChange={(e) => update('gender', e.target.value)}>
                  <option value="">Select...</option>
                  <option value="woman">Woman</option>
                  <option value="man">Man</option>
                  <option value="other">Other</option>
                </select>
              </div>
            </div>
            <div>
              <label style={labelStyle}>Email</label>
              <input style={inputStyle} type="email" value={form.email}
                onChange={(e) => update('email', e.target.value)} placeholder="you@email.com" />
            </div>
            <div>
              <label style={labelStyle}>City in Guyana</label>
              <select style={{ ...inputStyle, appearance: 'auto' }} value={form.city}
                onChange={(e) => update('city', e.target.value)}>
                {GUYANA_CITIES.map((c) => <option key={c} value={c}>{c}</option>)}
              </select>
            </div>
            <button style={primaryBtnStyle} onClick={() => {
              if (form.name && form.age && form.email) setStep(2);
            }}>
              Continue →
            </button>
          </div>
        )}

        {step === 2 && (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
            <div>
              <label style={labelStyle}>WhatsApp Number</label>
              <input style={inputStyle} value={form.phone}
                onChange={(e) => update('phone', e.target.value)}
                placeholder="+592 600 0000" />
              <p style={{ fontSize: 11, color: '#555', marginTop: 4 }}>
                This is how people will contact you
              </p>
            </div>
            <div>
              <label style={labelStyle}>About You</label>
              <textarea style={{ ...inputStyle, height: 90, resize: 'none' }} value={form.bio}
                onChange={(e) => update('bio', e.target.value)}
                placeholder="What makes you interesting? Hobbies, passions, what you're looking for..." />
            </div>
            <div style={{ display: 'flex', gap: 12 }}>
              <button onClick={() => setStep(1)} style={{
                ...primaryBtnStyle, background: 'transparent',
                border: '1px solid #444', flex: 1,
              }}>
                ← Back
              </button>
              <button style={{ ...primaryBtnStyle, flex: 2 }} onClick={() => {
                if (form.phone) setDone(true);
              }}>
                🔥 Create My Profile
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

const overlayStyle = {
  position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.8)',
  backdropFilter: 'blur(8px)', zIndex: 200,
  display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 20,
};

const modalStyle = {
  position: 'relative', maxWidth: 460, width: '100%',
  borderRadius: 24, background: '#111',
  border: '1px solid rgba(255,255,255,0.06)', padding: 36,
  animation: 'fadeUp 0.3s ease',
  maxHeight: '90vh', overflowY: 'auto',
};

const closeBtnStyle = {
  position: 'absolute', top: 16, right: 16,
  background: 'rgba(255,255,255,0.05)', border: 'none', color: '#888',
  width: 36, height: 36, borderRadius: '50%',
  display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer',
};

const primaryBtnStyle = {
  background: 'linear-gradient(135deg, #FF6B35, #E8522A)',
  border: 'none', color: '#fff', padding: '16px 24px', borderRadius: 12,
  fontSize: 16, fontWeight: 600, cursor: 'pointer', marginTop: 8,
  transition: 'transform 0.2s', width: '100%', textAlign: 'center',
};
