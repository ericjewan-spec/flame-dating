import { useState } from 'react';
import { WhatsAppIcon, MapPinIcon, CameraIcon, VerifiedIcon } from './Icons';

export default function ProfileCard({ profile, onOpenGallery }) {
  const [hovered, setHovered] = useState(false);
  const waLink = `https://wa.me/${profile.phone.replace(/[^0-9]/g, '')}?text=Hey%20${profile.name}%20👋%20I%20found%20you%20on%20Flame!`;

  return (
    <div
      style={{
        borderRadius: 20, overflow: 'hidden', background: 'var(--bg-card)',
        transition: 'all 0.35s cubic-bezier(.25,.8,.25,1)', cursor: 'default',
        transform: hovered ? 'translateY(-8px) scale(1.02)' : 'translateY(0) scale(1)',
        boxShadow: hovered
          ? '0 24px 60px rgba(255,107,53,0.2), 0 0 0 1px rgba(255,107,53,0.15)'
          : '0 8px 32px rgba(0,0,0,0.4), 0 0 0 1px rgba(255,255,255,0.05)',
      }}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
    >
      {/* Image */}
      <div style={{ position: 'relative', height: 340, overflow: 'hidden', cursor: 'pointer' }}
        onClick={() => onOpenGallery(profile)}>
        <img src={profile.photos[0]} alt={profile.name} style={{
          width: '100%', height: '100%', objectFit: 'cover',
          transition: 'transform 0.5s',
          transform: hovered ? 'scale(1.05)' : 'scale(1)',
        }} />
        <div style={{
          position: 'absolute', inset: 0,
          background: 'linear-gradient(to top, rgba(0,0,0,0.85) 0%, rgba(0,0,0,0.1) 40%, transparent 60%)',
        }} />

        {/* Photo count badge */}
        <div style={{
          position: 'absolute', top: 12, right: 12,
          background: 'rgba(0,0,0,0.6)', backdropFilter: 'blur(8px)',
          borderRadius: 20, padding: '5px 12px', fontSize: 13, color: '#fff',
          display: 'flex', alignItems: 'center', gap: 6,
        }}>
          <CameraIcon size={14} /> {profile.photos.length}
        </div>

        {/* Verified badge */}
        {profile.verified && (
          <div style={{
            position: 'absolute', top: 12, left: 12,
            background: 'rgba(0,0,0,0.6)', backdropFilter: 'blur(8px)',
            borderRadius: 20, padding: '5px 12px', fontSize: 12, color: '#4ade80',
            display: 'flex', alignItems: 'center', gap: 4,
          }}>
            <VerifiedIcon size={14} /> Verified
          </div>
        )}

        {/* Name overlay */}
        <div style={{ position: 'absolute', bottom: 16, left: 16, right: 16 }}>
          <h3 style={{
            fontFamily: 'var(--font-display)', fontSize: 24, fontWeight: 600, margin: 0,
            textShadow: '0 2px 8px rgba(0,0,0,0.5)', display: 'flex', alignItems: 'center', gap: 8,
          }}>
            {profile.name}, {profile.age}
          </h3>
          <p style={{
            fontSize: 13, color: '#ccc', margin: '4px 0 0',
            display: 'flex', alignItems: 'center', gap: 4,
          }}>
            <MapPinIcon size={13} /> {profile.city}, Guyana
          </p>
        </div>
      </div>

      {/* Body */}
      <div style={{ padding: '16px 20px 20px' }}>
        <div style={{
          display: 'inline-block', padding: '4px 14px', borderRadius: 50, fontSize: 12,
          fontWeight: 500, background: 'rgba(255,107,53,0.1)', color: '#FF6B35',
          border: '1px solid rgba(255,107,53,0.2)', marginBottom: 10,
        }}>
          🇬🇾 {profile.nationality}
        </div>

        <p style={{ fontSize: 14, color: 'var(--text-secondary)', lineHeight: 1.6, marginBottom: 12 }}>
          {profile.bio}
        </p>

        <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap', marginBottom: 16 }}>
          {profile.interests.map((i) => (
            <span key={i} style={{
              padding: '4px 12px', borderRadius: 50, fontSize: 11,
              background: 'rgba(255,255,255,0.05)', color: 'var(--text-dim)',
              border: '1px solid rgba(255,255,255,0.08)',
            }}>{i}</span>
          ))}
        </div>

        <div style={{ display: 'flex', gap: 10 }}>
          <a href={waLink} target="_blank" rel="noopener noreferrer" style={{
            flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8,
            padding: '12px 16px', borderRadius: 12, background: 'var(--wa-green)', color: '#fff',
            fontSize: 14, fontWeight: 600, transition: 'transform 0.2s',
          }}>
            <WhatsAppIcon size={18} /> WhatsApp
          </a>
          <button onClick={() => onOpenGallery(profile)} style={{
            flex: 1, padding: '12px 16px', borderRadius: 12,
            background: 'rgba(255,255,255,0.05)', border: '1px solid var(--border-medium)',
            color: '#ccc', fontSize: 14, transition: 'all 0.2s',
          }}>
            View Gallery
          </button>
        </div>
      </div>
    </div>
  );
}
