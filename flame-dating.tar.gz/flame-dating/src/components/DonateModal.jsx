import { useState } from 'react';
import { FlameIcon, CloseIcon } from './Icons';
import { DONATION_TIERS } from '../data/profiles';

export default function DonateModal({ onClose }) {
  const [selectedTier, setSelectedTier] = useState(null);
  const [customAmount, setCustomAmount] = useState('');
  const [thanked, setThanked] = useState(false);

  const handleDonate = () => {
    setThanked(true);
  };

  if (thanked) {
    return (
      <div style={overlayStyle} onClick={onClose}>
        <div style={modalStyle} onClick={(e) => e.stopPropagation()}>
          <div style={{ textAlign: 'center', padding: '50px 24px' }}>
            <div style={{ fontSize: 64, marginBottom: 16 }}>❤️</div>
            <h2 style={{ fontFamily: 'var(--font-display)', fontSize: 28, color: '#F7C948' }}>
              Thank You, Legend!
            </h2>
            <p style={{ color: '#aaa', fontSize: 15, marginTop: 12, lineHeight: 1.7 }}>
              Your support keeps Flame alive and free for everyone in Guyana.
              You're officially a Flame Patron. 🔥
            </p>
            <button onClick={onClose} style={primaryBtnStyle}>
              Back to Browsing
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div style={overlayStyle} onClick={onClose}>
      <div style={modalStyle} onClick={(e) => e.stopPropagation()}>
        <button onClick={onClose} style={closeBtnStyle}><CloseIcon size={18} /></button>

        <div style={{ textAlign: 'center', marginBottom: 28 }}>
          <div style={{ fontSize: 40, marginBottom: 8 }}>❤️‍🔥</div>
          <h2 style={{ fontFamily: 'var(--font-display)', fontSize: 28, fontWeight: 700 }}>
            Support Flame
          </h2>
          <p style={{ color: 'var(--text-dim)', margin: '8px 0 0', fontSize: 14, lineHeight: 1.6 }}>
            Flame is free for all Guyanese singles. Help us keep it that way.
          </p>
        </div>

        {/* Tier cards */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, marginBottom: 20 }}>
          {DONATION_TIERS.map((tier) => (
            <button
              key={tier.amount}
              onClick={() => { setSelectedTier(tier.amount); setCustomAmount(''); }}
              style={{
                background: selectedTier === tier.amount
                  ? 'rgba(255,107,53,0.15)' : 'rgba(255,255,255,0.03)',
                border: selectedTier === tier.amount
                  ? '2px solid #FF6B35' : '1px solid rgba(255,255,255,0.08)',
                borderRadius: 16, padding: '16px 12px', cursor: 'pointer',
                textAlign: 'center', transition: 'all 0.2s',
              }}
            >
              <div style={{ fontSize: 28, marginBottom: 4 }}>{tier.emoji}</div>
              <div style={{
                fontSize: 18, fontWeight: 700, color: '#fff',
                fontFamily: 'var(--font-display)',
              }}>{tier.label}</div>
              <div style={{ fontSize: 12, color: '#888', marginTop: 2 }}>{tier.desc}</div>
            </button>
          ))}
        </div>

        {/* Custom amount */}
        <div style={{ marginBottom: 20 }}>
          <label style={{
            fontSize: 12, textTransform: 'uppercase', letterSpacing: 1,
            color: 'var(--text-muted)', marginBottom: 6, display: 'block',
          }}>
            Or enter a custom amount (GYD)
          </label>
          <input
            type="number"
            value={customAmount}
            onChange={(e) => { setCustomAmount(e.target.value); setSelectedTier(null); }}
            placeholder="Enter amount..."
            style={{
              background: 'var(--bg-input)', border: '1px solid #2a2a2a', borderRadius: 12,
              padding: '14px 16px', color: 'var(--text-primary)', fontSize: 15,
              fontFamily: 'var(--font-body)', outline: 'none', width: '100%',
            }}
          />
        </div>

        {/* Payment info */}
        <div style={{
          background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.06)',
          borderRadius: 12, padding: 16, marginBottom: 20,
        }}>
          <p style={{ fontSize: 13, color: '#888', lineHeight: 1.7 }}>
            💳 <strong style={{ color: '#ccc' }}>How to donate:</strong> Send via mobile money,
            bank transfer, or contact us on WhatsApp. All donations go directly to keeping Flame
            running and ad-free for Guyana.
          </p>
          <a href="https://wa.me/5926001000?text=I%20want%20to%20donate%20to%20Flame!%20🔥"
            target="_blank" rel="noopener noreferrer"
            style={{
              display: 'inline-flex', alignItems: 'center', gap: 6,
              color: '#25D366', fontSize: 13, fontWeight: 600, marginTop: 8,
            }}>
            💬 WhatsApp us to arrange payment
          </a>
        </div>

        <button
          onClick={handleDonate}
          disabled={!selectedTier && !customAmount}
          style={{
            ...primaryBtnStyle,
            background: (!selectedTier && !customAmount)
              ? '#333' : 'linear-gradient(135deg, #F7C948, #FF6B35)',
            cursor: (!selectedTier && !customAmount) ? 'not-allowed' : 'pointer',
            color: (!selectedTier && !customAmount) ? '#666' : '#000',
            fontWeight: 700,
          }}
        >
          ❤️ Donate {selectedTier
            ? DONATION_TIERS.find(t => t.amount === selectedTier)?.label
            : customAmount ? `GY$${Number(customAmount).toLocaleString()}` : ''}
        </button>

        <p style={{ textAlign: 'center', fontSize: 11, color: '#444', marginTop: 12 }}>
          Flame is a community project. Every dollar helps. 🇬🇾
        </p>
      </div>
    </div>
  );
}

const overlayStyle = {
  position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.8)',
  backdropFilter: 'blur(8px)', zIndex: 200,
  display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 20,
};

const modalStyle = {
  position: 'relative', maxWidth: 460, width: '100%',
  borderRadius: 24, background: '#111',
  border: '1px solid rgba(255,255,255,0.06)', padding: 36,
  animation: 'fadeUp 0.3s ease',
  maxHeight: '90vh', overflowY: 'auto',
};

const closeBtnStyle = {
  position: 'absolute', top: 16, right: 16,
  background: 'rgba(255,255,255,0.05)', border: 'none', color: '#888',
  width: 36, height: 36, borderRadius: '50%',
  display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer',
};

const primaryBtnStyle = {
  background: 'linear-gradient(135deg, #FF6B35, #E8522A)',
  border: 'none', color: '#fff', padding: '16px 24px', borderRadius: 12,
  fontSize: 16, fontWeight: 600, cursor: 'pointer',
  transition: 'transform 0.2s', width: '100%', textAlign: 'center',
};
