import { useState, useEffect } from 'react';
import { WhatsAppIcon, CloseIcon, MapPinIcon, VerifiedIcon } from './Icons';

export default function GalleryModal({ profile, onClose }) {
  const [idx, setIdx] = useState(0);

  useEffect(() => {
    const handler = (e) => {
      if (e.key === 'Escape') onClose();
      if (e.key === 'ArrowRight') setIdx((i) => Math.min(profile.photos.length - 1, i + 1));
      if (e.key === 'ArrowLeft') setIdx((i) => Math.max(0, i - 1));
    };
    window.addEventListener('keydown', handler);
    document.body.style.overflow = 'hidden';
    return () => {
      window.removeEventListener('keydown', handler);
      document.body.style.overflow = '';
    };
  }, [onClose, profile.photos.length]);

  const waLink = `https://wa.me/${profile.phone.replace(/[^0-9]/g, '')}?text=Hey%20${profile.name}%20👋%20I%20found%20you%20on%20Flame!`;

  return (
    <div style={{
      position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.85)',
      backdropFilter: 'blur(12px)', zIndex: 200,
      display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 20,
    }} onClick={onClose}>
      <div style={{
        position: 'relative', maxWidth: 520, width: '100%',
        borderRadius: 24, overflow: 'hidden', background: '#111',
        border: '1px solid rgba(255,255,255,0.06)',
        animation: 'fadeUp 0.3s ease',
      }} onClick={(e) => e.stopPropagation()}>

        {/* Close button */}
        <button onClick={onClose} style={{
          position: 'absolute', top: 12, right: 12, zIndex: 10,
          background: 'rgba(0,0,0,0.6)', backdropFilter: 'blur(8px)',
          border: 'none', color: '#fff', width: 40, height: 40, borderRadius: '50%',
          display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer',
        }}>
          <CloseIcon size={18} />
        </button>

        {/* Image */}
        <div style={{ position: 'relative' }}>
          <img src={profile.photos[idx]} alt={profile.name} style={{
            width: '100%', height: 480, objectFit: 'cover',
          }} />

          {/* Dot indicators */}
          <div style={{
            position: 'absolute', top: 12, left: '50%', transform: 'translateX(-50%)',
            display: 'flex', gap: 6,
          }}>
            {profile.photos.map((_, i) => (
              <button key={i} onClick={() => setIdx(i)} style={{
                width: i === idx ? 24 : 8, height: 8, borderRadius: 4,
                background: i === idx ? '#FF6B35' : 'rgba(255,255,255,0.4)',
                border: 'none', transition: 'all 0.3s', cursor: 'pointer',
              }} />
            ))}
          </div>

          {/* Nav arrows */}
          {idx > 0 && (
            <button onClick={() => setIdx(idx - 1)} style={{
              position: 'absolute', left: 12, top: '50%', transform: 'translateY(-50%)',
              background: 'rgba(0,0,0,0.5)', backdropFilter: 'blur(8px)',
              border: 'none', color: '#fff', width: 44, height: 44, borderRadius: '50%',
              fontSize: 22, display: 'flex', alignItems: 'center', justifyContent: 'center',
              cursor: 'pointer',
            }}>‹</button>
          )}
          {idx < profile.photos.length - 1 && (
            <button onClick={() => setIdx(idx + 1)} style={{
              position: 'absolute', right: 12, top: '50%', transform: 'translateY(-50%)',
              background: 'rgba(0,0,0,0.5)', backdropFilter: 'blur(8px)',
              border: 'none', color: '#fff', width: 44, height: 44, borderRadius: '50%',
              fontSize: 22, display: 'flex', alignItems: 'center', justifyContent: 'center',
              cursor: 'pointer',
            }}>›</button>
          )}
        </div>

        {/* Info panel */}
        <div style={{ padding: '20px 24px 24px' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 6 }}>
            <h3 style={{ fontFamily: 'var(--font-display)', fontSize: 24, fontWeight: 600 }}>
              {profile.name}, {profile.age}
            </h3>
            {profile.verified && <VerifiedIcon size={20} />}
          </div>
          <p style={{ fontSize: 13, color: '#aaa', display: 'flex', alignItems: 'center', gap: 4, marginBottom: 12 }}>
            <MapPinIcon size={13} /> {profile.city}, Guyana
          </p>
          <p style={{ fontSize: 14, color: '#ccc', lineHeight: 1.6, marginBottom: 16 }}>
            {profile.bio}
          </p>
          <a href={waLink} target="_blank" rel="noopener noreferrer" style={{
            display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 10,
            padding: '14px 24px', borderRadius: 14, background: 'var(--wa-green)', color: '#fff',
            fontSize: 16, fontWeight: 600, width: '100%',
          }}>
            <WhatsAppIcon size={22} /> Message {profile.name} on WhatsApp
          </a>
        </div>
      </div>
    </div>
  );
}
