import { useState } from 'react';
import { Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import GalleryModal from './components/GalleryModal';
import SignUpModal from './components/SignUpModal';
import DonateModal from './components/DonateModal';
import HomePage from './pages/HomePage';
import BrowsePage from './pages/BrowsePage';

export default function App() {
  const [showSignUp, setShowSignUp] = useState(false);
  const [showDonate, setShowDonate] = useState(false);
  const [galleryProfile, setGalleryProfile] = useState(null);

  return (
    <div style={{ minHeight: '100vh', display: 'flex', flexDirection: 'column' }}>
      <Navbar
        onSignUp={() => setShowSignUp(true)}
        onDonate={() => setShowDonate(true)}
      />

      <main style={{ flex: 1 }}>
        <Routes>
          <Route
            path="/"
            element={
              <HomePage
                onSignUp={() => setShowSignUp(true)}
                onDonate={() => setShowDonate(true)}
              />
            }
          />
          <Route
            path="/browse"
            element={
              <BrowsePage
                onOpenGallery={setGalleryProfile}
                onSignUp={() => setShowSignUp(true)}
              />
            }
          />
        </Routes>
      </main>

      <Footer onDonate={() => setShowDonate(true)} />

      {/* Modals */}
      {galleryProfile && (
        <GalleryModal
          profile={galleryProfile}
          onClose={() => setGalleryProfile(null)}
        />
      )}
      {showSignUp && <SignUpModal onClose={() => setShowSignUp(false)} />}
      {showDonate && <DonateModal onClose={() => setShowDonate(false)} />}
    </div>
  );
}
